package com.gfg.stringtomcatapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StringtomcatapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(StringtomcatapplicationApplication.class, args);
	}

}
