package com.gfg.stringtomcatapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StringtomcatapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
